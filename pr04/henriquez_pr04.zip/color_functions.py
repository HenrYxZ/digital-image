def linear_function(color):
    new_color = color.copy()
    return new_color


def change_hue(i, j, color):
    new_color = color.copy()
    return new_color
